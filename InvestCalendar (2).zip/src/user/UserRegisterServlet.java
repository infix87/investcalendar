package user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UserRegisterServlet")
public class UserRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF=8");
		
		String userID = request.getParameter("userID");
		String userPassword = request.getParameter("userPassword1");
		String userName = request.getParameter("userName");
		String userAge = request.getParameter("userAge");
		String userGender = request.getParameter("userGender");
		String userEmail = request.getParameter("userEmail");
		String userArea = request.getParameter("userArea");
		String userTel = request.getParameter("userTel");
		
		if(userID == null || userID.equals("") || userPassword == null || userPassword.equals("") || userName == null || userName.equals("") 
				|| userAge == null || userAge.equals("") || userGender == null || userGender.equals("") || userEmail == null || userEmail.equals("")
				|| userArea == null || userArea.equals("") || userTel == null || userTel.equals("")) {
			request.getSession().setAttribute("messageType", "���� �޽���");
			request.getSession().setAttribute("messageContent", "��� ������ �Է��ϼ���.");
			response.sendRedirect("join.jsp");
			return;
		}

		int result = new UserDAO().register(userID, userPassword, userName, userAge, userGender, userEmail, userArea, userTel);
		if(result == 1) {
			request.getSession().setAttribute("messageType", "���� �޽���");
			request.getSession().setAttribute("messageContent", "ȸ�����Կ� �����߽��ϴ�.");
			response.sendRedirect("index.jsp");
			return;
		} 
		else {
			request.getSession().setAttribute("messageType", "���� �޽���");
			request.getSession().setAttribute("messageContent", "�̹� ����Ǿ��ִ� ���̵��Դϴ�.");
			response.sendRedirect("join.jsp");			
			return;
		}		
	}

}
