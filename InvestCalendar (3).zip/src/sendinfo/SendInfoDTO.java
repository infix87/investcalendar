package sendinfo;

public class SendInfoDTO {
	int infoID;
	String infoSendID;
	String infoName;
	String infoTitle;
	String infoBody;
	String infoLink;
	String infoUploadDate;
	
	public int getInfoID() {
		return infoID;
	}
	public void setInfoID(int infoID) {
		this.infoID = infoID;
	}
	public String getInfoSendID() {
		return infoSendID;
	}
	public void setInfoSendID(String infoSendID) {
		this.infoSendID = infoSendID;
	}
	public String getInfoName() {
		return infoName;
	}
	public void setInfoName(String infoName) {
		this.infoName = infoName;
	}
	public String getInfoTitle() {
		return infoTitle;
	}
	public void setInfoTitle(String infoTitle) {
		this.infoTitle = infoTitle;
	}
	public String getInfoBody() {
		return infoBody;
	}
	public void setInfoBody(String infoBody) {
		this.infoBody = infoBody;
	}
	public String getInfoLink() {
		return infoLink;
	}
	public void setInfoLink(String infoLink) {
		this.infoLink = infoLink;
	}
	public String getInfoUploadDate() {
		return infoUploadDate;
	}
	public void setInfoUploadDate(String infoUploadDate) {
		this.infoUploadDate = infoUploadDate;
	}
	public String getInfoDate() {
		return infoDate;
	}
	public void setInfoDate(String infoDate) {
		this.infoDate = infoDate;
	}
	public int getInfoAvailable() {
		return infoAvailable;
	}
	public void setInfoAvailable(int infoAvailable) {
		this.infoAvailable = infoAvailable;
	}
	String infoDate;
	int infoAvailable; 
}
